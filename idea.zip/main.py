import vkapi
import vk
import time
from urllib.request import urlretrieve
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget
from PyQt5 import uic, QtWidgets
import sys


class Photo(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('album.ui', self)
        self.pushButton.clicked.connect(self.delete)


class Afk_f(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('afk_f.ui', self)
        self.pushButton.clicked.connect(self.delete)

    def delete(self):
        delete_afk_friends()


class Ban_f(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('ban_f.ui', self)
        self.pushButton.clicked.connect(self.delete)

    def delete(self):
        delete_afk_friends()


class Album(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('album.ui', self)
        self.DownloadAlbum.clicked.connect(self.download)

    def download(self):
        path = self.lineEdit_4.text()
        token = self.lineEdit_3.text()
        start = self.lineEdit_2.text()
        end = self.lineEdit.text()
        download_photo_album(path, token, start, end)

class Wall(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('del_g.ui', self)
        self.DownloadAlbum.clicked.connect(self.download)

    def download(self):
        path = self.lineEdit_4.text()
        token = self.lineEdit_3.text()
        owner = self.lineEdit_2.text()
        album = self.lineEdit.text()
        download_photo_album(path, token, owner, album)


class Authorize_Window(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('vk_app.ui', self)
        self.menu.hide()
        self.start.show()
        self.authorize()

    def authorize(self):
        global vk_token
        self.client_id = self.Enter_ID.text()
        self.redirect_uri = f'https://vk.com/editapp?id={self.client_id}'
        self.Get_Code.clicked.connect(self.authorize1)
        self.vk_code = self.Enter_Code.text()
        self.service_key = self.Enter_Protect.text()
        self.get_token.clicked.connect(self.final)

    def final(self):
        self.client_id = self.Enter_ID.text()
        self.vk_code = self.Enter_Code.text()
        self.service_key = self.Enter_Protect.text()
        self.session_2 = f'https://oauth.vk.com/access_token?client_id={self.client_id}&client_secret={self.service_key}&redirect_uri={self.redirect_uri}&code={self.vk_code}'
        self.Link_VK_Token.setText(self.session_2)


    def start_to_menu(self):
        self.Continue.clicked.connect(lambda: self.start.hide())
        self.Continue.clicked.connect(lambda: self.menu.show())
        self.Album.clicked.connect(lambda: album.show())
        self.Del_Ban_Friends.clicked.connect(lambda: ban_f.show())
        self.Del_AFK_Friends.clicked.connect(lambda: afk_f.show())
        self.Download_Photo.clicked.connect(lambda: wall.show())
        self.Del_Publics.clicked.connect(lambda: afk_f.show())
        self.Del_Noti.clicked.connect(lambda: afk_f.show())
        self.Establish_Status.clicked.connect(lambda: afk_f.show())


    def authorize1(self):
        self.client_id = self.Enter_ID.text()
        self.redirect_uri = f'https://vk.com/editapp?id={self.client_id}'
        self.session = f'https://oauth.vk.com/authorize?client_id={self.client_id}&display=page&redirect_uri={self.redirect_uri}&scope=notifications,friends&response_type=code&v=5.131'
        self.Code_Link.setText(self.session)


def download_photo_album(path, token, owner_id, album_id):
    vkapi = vk.API(token)
    photos = vkapi.photos.get(owner_id=owner_id, album_id=album_id, count=1000, v=5.131, photo_sizes=1) # получаем список фото
    number_photo = 0
    for photo in photos['items']: # проходимся по фото
        max_size_photo = photo['sizes']
        max_size_photo.sort(key=lambda x: 'height') # берем фото с самым высоким разрешением
        f = open(f'{path[:]}\\album_{number_photo}.jpg', 'w') # создаем файл
        url = max_size_photo[-1]['url'] # получаем запрос изображения
        urlretrieve(url, f"{path[:]}\\album_{number_photo}.jpg") # скачиваем фото
        number_photo += 1
        f.close()


def delete_banned_friends():
    friends_list = vkapi.friends.get(v=5.81, fields='last_seen')
    for i in friends_list['items']:
        if 'deactivated' in i:
            vkapi.friends.delete(user_id=i['id'], v=5.81)
            time.sleep(0.25)


def delete_afk_friends():
    friends_list = vkapi.friends.get(v=5.81, fields='last_seen')
    for i in friends_list['items']:
        if 'last_seen' in i:
            if time.time() - i['last_seen']['time'] >= 31536000:
                vkapi.friends.delete(i['id'])
                time.sleep(0.25)


def download_wall_photo(path, owner_id, start, end):
    photos_count = end - start
    number_photo = 0
    photos = vkapi.photos.get(owner_id=owner_id, v=5.131, album_id='wall', offset=start, count=photos_count)['items'][::-1]
    for photo in photos:
        max_size_photo = photo['sizes']
        max_size_photo.sort(key=lambda x: 'height')
        f = open(f'{path[:]}\\wall_{number_photo}.jpg', 'w')
        url = max_size_photo[-1]['url']
        urlretrieve(url, f"{path[:]}\\wall_{number_photo}.jpg")
        number_photo += 1
        f.close()


def delete_afk_groups(owner_id):
    for i in vkapi.groups.get(owner_id=owner_id, v=5.81)['items']:
        checker = (vkapi.wall.get(owner_id=-i, v=5.81, count=2))
        time.sleep(0.25)
        if time.time() - checker['items'][0]['date'] >= 31536000 and time.time() - checker['items'][1]['date'] >= 31536000:
            vkapi.groups.leave(owner_id=checker['items'][0]['from_id'])


def del_notifications():
    vkapi.notifications.markAsViewed(v=5.81)


def set_status(text):
    vkapi.status.set(text=text)


if __name__ == '__main__':
    vk_token = 'vk1.a.uWldt5nQXFm4zCl1wOe6ITag4pwvKfpoOpboLILOocRBc4eai_AvkVmVZKoSIz679PP3U5JPqh4qWcph0YFyRCthn_qPc_260VLHey3npGdT9VKBc6VDHZz_NXxysuj8KIfsRkk65AbTXntlMnAwwgr_3jL2hP-TD3ZodEXEgMiWyy_MdnfzAQotvxC5zXeZ'
    vkapi = vk.API(vk_token)
    app = QApplication(sys.argv)
    afk_f = Afk_f()
    ban_f = Ban_f()
    album = Album()
    wall = Wall()
    ex = Authorize_Window()
    ex.show()
    ex.start_to_menu()
    sys.exit(app.exec_())
